#define CUBIST_INPUT_STRING_SIZE 1024

void initiateCubist();
double XactAverageExecutionTimes_getPrediction(char * attr);
